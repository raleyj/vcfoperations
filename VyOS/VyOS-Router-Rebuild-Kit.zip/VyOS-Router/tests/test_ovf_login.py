"""Run inside VyOS, using its real ConfigTree implementation, without changing it."""
import base64
import importlib.util
from pathlib import Path
import unittest
from xml.sax.saxutils import escape

module_path = Path(__file__).with_name('vyos-firstboot.py')
if not module_path.exists():
    module_path = Path('/opt/vyatta/etc/config/scripts/vyos-firstboot.py')
spec = importlib.util.spec_from_file_location('firstboot', module_path)
boot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(boot)
ConfigTree = boot.ConfigTree

BASE = '''interfaces {
    ethernet eth0 {
        address "dhcp"
    }
}
system {
    host-name "fixture"
    login {
        user vyos {
            authentication {
                encrypted-password "oldhash"
                plaintext-password "old-password"
            }
        }
    }
}
'''
PASSWORD = 'Unit-test & <safe> "quotes" $;\\pass123'


def xml(username='routeradmin', password=PASSWORD, namespace='http://schemas.dmtf.org/ovf/environment/1'):
    def attr(s): return escape(s, {'"':'&quot;'})
    return f'''<Environment xmlns="{namespace}" xmlns:oe="{namespace}"><PropertySection>
    <Property oe:key="username" oe:value="{attr(username)}"/>
    <Property oe:key="password" oe:value="{attr(password)}"/>
    </PropertySection></Environment>'''


class LoginTests(unittest.TestCase):
    def test_renamed_account_and_hash(self):
        result = boot.prepare_config(BASE, '', xml())
        tree = ConfigTree(result)
        self.assertFalse(tree.exists(['system','login','user','vyos']))
        self.assertTrue(tree.exists(['system','login','user','routeradmin','authentication','encrypted-password']))
        value = tree.return_value(['system','login','user','routeradmin','authentication','encrypted-password'])
        self.assertEqual(boot.crypt.crypt(PASSWORD, value), value)
        self.assertNotIn(PASSWORD, result)
        self.assertNotIn('plaintext-password', result)
        self.assertIn('user routeradmin {', result)

    def test_creates_login_in_config_without_one(self):
        payload = base64.b64encode(b'system {\n    host-name "empty-login"\n}\n').decode()
        result = boot.prepare_config(BASE, payload, xml())
        self.assertIn('user routeradmin {', result)

    def test_existing_username_password_replaced(self):
        tree = ConfigTree(boot.prepare_config(BASE, '', xml('vyos')))
        self.assertEqual(tree.list_nodes(['system','login','user']), ['vyos'])
        self.assertFalse(tree.exists(['system','login','user','vyos','authentication','plaintext-password']))

    def test_config_and_login_precedence(self):
        payload = base64.b64encode(BASE.replace('fixture','supplied').encode()).decode()
        result = boot.prepare_config(BASE, payload, xml())
        self.assertEqual(ConfigTree(result).return_value(['system','host-name']), 'supplied')
        self.assertTrue(ConfigTree(result).exists(['system','login','user','routeradmin']))

    def test_config_only_and_no_customization(self):
        self.assertIsNone(boot.prepare_config(BASE, '', ''))
        payload = base64.b64encode(BASE.encode()).decode()
        self.assertTrue(ConfigTree(boot.prepare_config('', payload, '')).exists(['system','login','user','vyos']))

    def test_namespace_variants(self):
        self.assertEqual(boot.ovf_credentials(xml(namespace='http://schemas.dmtf.org/ovf/envelope/1'))[0], 'routeradmin')

    def test_invalid_login_rejected(self):
        for username in ['root','daemon','bad user','admin;touch','Admin','a'*33]:
            with self.subTest(username=username), self.assertRaises(ValueError):
                boot.ovf_credentials(xml(username))
        for password in ['', 'short', 'x'*129, 'long-password\n']:
            with self.subTest(length=len(password)), self.assertRaises(ValueError):
                boot.ovf_credentials(xml(password=password).replace('\n', '&#10;'))

    def test_untrusted_inputs_rejected(self):
        for content in ['<bad', '<!DOCTYPE x><Environment/>']:
            with self.assertRaises(ValueError): boot.ovf_credentials(content)
        with self.assertRaises(ValueError): boot.prepare_config(BASE, 'not base64!', '')
        with self.assertRaises(ValueError): boot.prepare_config(BASE, base64.b64encode(b'system { broken').decode(), '')


if __name__ == '__main__':
    unittest.main(verbosity=2)
