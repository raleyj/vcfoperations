$ErrorActionPreference = 'Stop'
$testDirectory = Join-Path $PSScriptRoot 'tests\output'
[IO.Directory]::CreateDirectory($testDirectory) | Out-Null
$example = Join-Path $PSScriptRoot 'vyos-router.definition.json.example'
$generator = Join-Path $PSScriptRoot 'New-VyOSRouterConfig.ps1'
function Assert-Contains([string]$Text, [string]$Expected) {
    if (-not $Text.Contains($Expected)) { throw "Missing expected output: $Expected" }
}
$output = Join-Path $testDirectory 'dhcp-bgp.config.boot'
& $generator -DefinitionFile $example -OutputPath $output
$text = Get-Content $output -Raw
foreach ($expected in @('subnet-id 1', 'option {', 'name-server "1.1.1.1"', 'system-as "65001"', 'vif 10')) { Assert-Contains $text $expected }
if ($text -match 'dns-server') { throw 'Legacy DHCP syntax found.' }

$definition = Get-Content $example -Raw | ConvertFrom-Json
$definition.wan.addressMode = 'static'
$definition.wan | Add-Member -NotePropertyName address -NotePropertyValue '192.0.2.2/24'
$definition.wan | Add-Member -NotePropertyName gateway -NotePropertyValue '192.0.2.1'
$definition.PSObject.Properties.Remove('bgp')
$definition.lans += [pscustomobject]@{
    name='SERVERS'; parentInterface='eth1'; vlanId=20; subnet='192.168.20.0/24'; gateway='192.168.20.1'
    dhcp=[pscustomobject]@{enabled=$true; start='192.168.20.100'; stop='192.168.20.200'; dnsServers=@('1.1.1.1')}
}
$json = Join-Path $testDirectory 'static-multiple-lans.json'
$definition | ConvertTo-Json -Depth 10 | Set-Content $json
$output = Join-Path $testDirectory 'static-multiple-lans.config.boot'
& $generator -DefinitionFile $json -OutputPath $output
$text = Get-Content $output -Raw
foreach ($expected in @('route 0.0.0.0/0', 'next-hop 192.0.2.1', 'subnet-id 2', 'vif 20')) { Assert-Contains $text $expected }
if ($text -match '    bgp \{') { throw 'Unexpected BGP config.' }

$definition.hostname = "bad`nhost"
$definition | ConvertTo-Json -Depth 10 | Set-Content $json
$rejected = $false
try { & $generator -DefinitionFile $json -OutputPath (Join-Path $testDirectory 'must-not-exist.config.boot') } catch { $rejected = $true }
if (-not $rejected) { throw 'Newline injection was not rejected.' }
Write-Host 'PASS: DHCP/BGP example, static default route, multiple DHCP subnets, and newline rejection.'
