# VyOS Router OVA

Reconstructed on 2026-08-28 from the original build task and the locally retained
VyOS **2026.03 (circinus)** ISO. This is a new build, not a byte-for-byte recovery
of the former 2026.07.21 rolling image.

## Files and appliance

`dist/VyOS-Router.ova` is the deployable appliance. `VALIDATION.md` records the
actual validation results and limitations. The appliance includes open-vm-tools,
two VMXNET3 NICs (WAN/eth0 and LAN/eth1), a 10 GiB VMware Paravirtual SCSI disk,
and a default 2-vCPU/4-GiB profile.

## Set the login in the OVA deployment wizard

In vCenter, choose **Deploy OVF Template**, select the OVA, and continue to
**Customize template**. Under **VyOS administrator login**, enter:

- **Administrator username**: defaults to `vyos`. Use 1-32 lowercase letters,
  digits, underscores or hyphens; start with a letter. System accounts are reserved.
- **Administrator password**: required, 12-128 characters without control characters.
  The password field is masked and has no preset password.

After power-on, allow the appliance to finish configuration and reboot once.
Then log in with the username and password you supplied. Choosing a different
username removes the default `vyos` account from the active configuration.
These fields apply only on the first boot; they are not a password-reset facility.

The implementation uses the standard OVF environment through VMware Tools, not
cloud-init. Tools remain installed and enabled in the appliance.

## Bootstrap login and security

The initial bootstrap login is **vyos / vyos** until customization has completed.
Use a trusted or isolated deployment network until the reboot and new login are
verified. A manual import that delivers no OVF login properties or configuration
retains the bootstrap login. Without a supplied configuration, eth0 uses DHCP and
SSH is enabled. No production firewall policy is included.

The new password is hashed inside the guest; it is not written to guest scripts,
command arguments or config.boot in plaintext. Masking the wizard field does not
encrypt the OVF environment: privileged VM/platform administrators can access
deployment metadata. Do not share a configured VM or its files with login
properties still present. The OVA itself has no stored deployment password.

The example password hash also corresponds to `vyos`; the wizard credentials
override the selected account's password. Other explicitly supplied accounts are
preserved, except that `vyos` is removed when a different username is chosen.
No vCenter
credentials or saved site configuration are bundled. VMware Tools customizations
are baked into this image: a later VyOS image upgrade may require rebuilding them.

## Deploy with a config.boot file

```powershell
Copy-Item .\vyos-router.config.boot.example .\vyos-router.config.boot
# Edit the copy, including the password hash and network addresses.
.\deploy-vyos-vcenter.ps1 -VyOSConfigFile .\vyos-router.config.boot
```

The recovered script defaults to `vcenter.example.com`, datacenter `Datacenter`,
cluster `Cluster`, datastore `datastore1`, and port groups `VyOS-WAN`/`VyOS-LAN`.
Review before running. Override with `-VCenter`, `-Datacenter`, `-Cluster`,
`-Datastore`, `-WanPortGroup` and `-LanPortGroup`. Existing VMs are not replaced.
Use `-NoPowerOn` to inspect before booting. VMware PowerCLI is required.

The deployment script prompts separately for the new VyOS login. For scripted use,
pass `-VyOSCredential (Get-Credential -UserName vyos)`. This credential is not
written to the saved deployment settings.

The script sets `guestinfo.vyos.config-b64` before first power-on. The guest
installs that complete config.boot and reboots once. Include a usable login
account, or supply the OVF login fields to create one. The OVF login overrides the
selected account in this configuration. No VNC wizard or cloud-init is used.
For manual imports, use the login fields and/or set this guestinfo key before the
first power-on.

Injection runs from the VyOS post-configuration boot hook, after `/config` is
mounted. The previous config is saved as `/config/config.boot.before-injection`.
The supplied file is syntax-parsed, but routing policy and live network behavior
still require validation in your lab.

Base64 is **not encryption**. VM administrators can read this setting, and it
remains until removed. After confirming successful configuration, remove
`guestinfo.vyos.config-b64` from the VM advanced settings. Saved deployment
settings contain only the config file path, not its contents.

The script prompts for vCenter credentials. `save-vcenter-credential.ps1` can
optionally store a Windows DPAPI-encrypted credential for the same Windows user
and machine. No credential file is included.

## Generate VLAN, DHCP and BGP configuration

```powershell
Copy-Item .\vyos-router.definition.json.example .\vyos-router.definition.json
# Edit hostname, password hash, WAN, LANs, VLANs, DHCP ranges and BGP peers.
.\New-VyOSRouterConfig.ps1 -DefinitionFile .\vyos-router.definition.json
.\deploy-vyos-vcenter.ps1 -VyOSConfigFile .\vyos-router.config.boot
```

Omit `vlanId` for an untagged interface; omit `bgp` to disable BGP. Static WANs
require `address` in CIDR notation and `gateway`; the generator includes a default
route. DHCP syntax matches the Kea-based schema in the 2026.03 ISO. Replace the
illustrative BGP peer with a reachable peer. Validation is basic: review and test
generated routing policy before deployment.

## Rebuild

Requires PowerShell 7, Docker Desktop with Linux containers, and VMware OVF Tool
at its standard installation path. Allow at least 25 GiB of working disk space.
The build uses a privileged container for loop devices, mounts, GRUB and SquashFS.
It does not deploy to vCenter or modify existing VMs.

```powershell
.\build-vmware-agent-ova.ps1 -IsoPath .\input\vyos-2026.03-generic-amd64.iso
.\Test-ConfigGenerator.ps1
```

The retained `vyos-vmware-image-builder:latest` image is reused. If absent it is
built; use `-RebuildBuilderImage` to force rebuilding. Every run gets a unique
directory and container name. Stopped build containers are retained for diagnosis
and can be removed by their exact names when no longer needed.

VMware Tools is installed from signed Debian Bookworm repositories using a
temporary source list. Existing VyOS package sources are preserved. Future builds
may select newer package versions. Verify your ISO against its distributor's
checksum. The local input SHA-256 records what was used; it does not independently
authenticate the publisher.

Original Packer/VNC scripts in the working folder are historical references.
Use the Docker workflow for this reconstruction. The source bundle excludes
history recovery records, credentials, generated private configs, test VM disks
and build intermediates. Supply the ISO separately when rebuilding from the ZIP.

## References

- [Original builder](https://github.com/vyos-legacy/vyos-vm-images)
- [DHCP schema](https://docs.vyos.io/en/1.5/configuration/service/dhcp-server.html)
- [Static routes](https://docs.vyos.io/en/rolling/configuration/protocols/static.html)

