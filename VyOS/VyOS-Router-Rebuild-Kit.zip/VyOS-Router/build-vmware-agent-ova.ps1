[CmdletBinding()]
param(
    [string]$IsoPath,
    [string]$OutputPath,
    [switch]$RebuildBuilderImage
)

$ErrorActionPreference = 'Stop'
if (-not $OutputPath) { $OutputPath = Join-Path $PSScriptRoot 'dist\VyOS-Router.ova' }
$docker = 'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
$env:PATH = 'C:\Program Files\Docker\Docker\resources\bin;' + $env:PATH
$ovftool = 'C:\Program Files\VMware\VMware OVF Tool\ovftool.exe'
$builderDirectory = Join-Path $PSScriptRoot 'vyos-vm-images'
$buildId = 'vyos-reconstruction-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
$builderOutput = Join-Path $PSScriptRoot "build\$buildId"

if (-not (Test-Path -LiteralPath $docker)) { throw 'Docker Desktop CLI was not found.' }
if (-not (Test-Path -LiteralPath $ovftool)) { throw 'VMware OVF Tool was not found.' }
if (-not $IsoPath) {
    $IsoPath = Join-Path $PSScriptRoot 'input\vyos-2026.03-generic-amd64.iso'
}
if (-not $IsoPath -or -not (Test-Path -LiteralPath $IsoPath)) { throw 'A VyOS ISO is required. Use -IsoPath to provide it.' }

$workspace = (Resolve-Path $PSScriptRoot).Path
$IsoPath = (Resolve-Path -LiteralPath $IsoPath).Path
New-Item -ItemType Directory -Force -Path $builderOutput, (Split-Path -Parent $OutputPath) | Out-Null

& $docker image inspect vyos-vmware-image-builder:latest *> $null
if ($RebuildBuilderImage -or $LASTEXITCODE -ne 0) {
    & $docker build --tag vyos-vmware-image-builder $builderDirectory
    if ($LASTEXITCODE -ne 0) { throw "Docker image build failed with exit code $LASTEXITCODE." }
}

Write-Host "Build directory: $builderOutput"
& $docker run --name $buildId --privileged `
    --volume "${workspace}:/workspace" `
    --volume "${builderOutput}:/tmp" `
    --mount "type=bind,source=$IsoPath,target=/input/vyos.iso,readonly" `
    --workdir /workspace/vyos-vm-images `
    vyos-vmware-image-builder `
    bash -lc "ansible-playbook -i hosts vmware.yml -e iso_local=/input/vyos.iso -e parttable_type=hybrid -e guest_agent=vmware -e enable_dhcp=true -e enable_ssh=true -e cloud_init=false -e custom_files=true -e firstboot_network_wizard=true -e vmware_export_ova=false"
if ($LASTEXITCODE -ne 0) { throw "VyOS VMware image build failed with exit code $LASTEXITCODE." }

$ovf = Join-Path $builderOutput 'vyos_vmware_image.ovf'
if (-not (Test-Path -LiteralPath $ovf)) { throw "Expected OVF was not produced: $ovf" }
& $ovftool --acceptAllEulas --overwrite $ovf $OutputPath
if ($LASTEXITCODE -ne 0) { throw "OVA export failed with exit code $LASTEXITCODE." }
& $ovftool --verifyOnly $OutputPath
if ($LASTEXITCODE -ne 0) { throw 'OVA validation failed.' }
Get-FileHash -Algorithm SHA256 -LiteralPath $OutputPath | Format-List
