"""Verify archive members and their manifest hashes without extracting the disk."""
import hashlib, json, re, tarfile
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
ova = root/'dist/VyOS-Router.ova'
ns = {'ovf':'http://schemas.dmtf.org/ovf/envelope/1'}
with tarfile.open(ova) as archive:
    members = archive.getmembers()
    assert all(m.isfile() and '/' not in m.name and '\\' not in m.name for m in members)
    assert members[0].name.endswith('.ovf')
    descriptor = ET.fromstring(archive.extractfile(members[0]).read())
    props = {p.attrib['{'+ns['ovf']+'}key']: p for p in descriptor.findall('.//ovf:Property',ns)}
    assert props['username'].attrib['{'+ns['ovf']+'}userConfigurable'] == 'true'
    assert props['password'].attrib['{'+ns['ovf']+'}userConfigurable'] == 'true'
    assert props['password'].attrib['{'+ns['ovf']+'}password'] == 'true'
    assert props['password'].attrib['{'+ns['ovf']+'}value'] == ''
    for ref in descriptor.findall('ovf:References/ovf:File',ns):
        name = ref.attrib['{'+ns['ovf']+'}href']
        assert archive.getmember(name).size == int(ref.attrib['{'+ns['ovf']+'}size'])
    manifest = next(m for m in members if m.name.endswith('.mf'))
    entries = archive.extractfile(manifest).read().decode().splitlines()
    verified = []
    for entry in entries:
        match = re.fullmatch(r'(SHA1|SHA256)\((.+)\)\s*=\s*([a-fA-F0-9]+)',entry.strip())
        assert match, entry
        algorithm,name,expected = match.groups()
        actual=hashlib.file_digest(archive.extractfile(name),algorithm.lower()).hexdigest()
        assert actual.lower()==expected.lower(),name
        verified.append(name)
    assert members[0].name in verified
    assert any(name.endswith('.vmdk') for name in verified)

def sha256(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

report = {
    'ova':str(ova),'bytes':ova.stat().st_size,'sha256':sha256(ova),
    'manifest_members_verified':verified,
    'deployment_login_properties_verified': ['username', 'password (masked; no default)'],
    'iso_sha256':sha256(root/'input/vyos-2026.03-generic-amd64.iso'),
}
(root/'dist/checksums.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
