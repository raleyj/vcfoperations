"""Create an allowlisted source ZIP; omit history, credentials and working disks."""
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
files=[
    'README.md','VALIDATION.md','build-vmware-agent-ova.ps1',
    'deploy-vyos-vcenter.ps1','save-vcenter-credential.ps1',
    'New-VyOSRouterConfig.ps1','Test-ConfigGenerator.ps1',
    'vyos-router.config.boot.example','vyos-router.definition.json.example',
    'verify_ova.py','package_source.py','dist/checksums.json',
    'tests/test_ovf_login.py',
]
paths=[root/name for name in files]
paths += [p for p in (root/'vyos-vm-images').rglob('*') if p.is_file()
          and not any(part in {'.git','output','__pycache__'} for part in p.relative_to(root).parts)]
output=root/'dist/VyOS-Router-Rebuild-Kit.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(paths):
        assert path.is_file(),path
        z.write(path,'VyOS-Router/'+path.relative_to(root).as_posix())
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    assert not any('/recovery/' in n or 'credential.clixml' in n or n.endswith('.ova') for n in z.namelist())
    print(f'{output}: {len(z.namelist())} files, {output.stat().st_size} bytes; ZIP CRCs verified.')
