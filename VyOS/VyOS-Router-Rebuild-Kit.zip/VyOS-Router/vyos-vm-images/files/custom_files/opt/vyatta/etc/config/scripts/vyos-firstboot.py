#!/usr/bin/python3
"""Apply a supplied config and OVF login once, after /config is mounted.

Secrets stay in memory; only a salted password hash is written to config.boot.
Never pass the password through shell commands, argv, environment, or logs.
"""
import base64
import os
from pathlib import Path
import pwd
import re
import subprocess
import sys
import tempfile
import warnings
import xml.etree.ElementTree as ET

with warnings.catch_warnings():
    warnings.simplefilter('ignore', DeprecationWarning)
    import crypt
from vyos.configtree import ConfigTree

MARKER = Path('/config/.config-file-applied')
CONFIG = Path('/config/config.boot')


def guestinfo(key):
    result = subprocess.run(['/usr/bin/vmtoolsd', '--cmd', 'info-get ' + key],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            text=True, timeout=20, check=False)
    return result.stdout if result.returncode == 0 else ''


def ovf_credentials(xml):
    if not xml.strip():
        return None
    if len(xml) > 1024 * 1024 or '<!DOCTYPE' in xml.upper() or '<!ENTITY' in xml.upper():
        raise ValueError('Unsupported OVF environment.')
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        raise ValueError('Invalid OVF environment XML.') from None
    props = {}
    for node in root.iter():
        if node.tag.rsplit('}', 1)[-1] != 'Property':
            continue
        attrs = {k.rsplit('}', 1)[-1]: v for k, v in node.attrib.items()}
        key = attrs.get('key')
        if key not in ('username', 'password'):
            continue
        if key in props:
            raise ValueError('Duplicate OVF login property.')
        props[key] = attrs.get('value', '')
    if not props:
        return None
    username = props.get('username', 'vyos')
    password = props.get('password', '')
    if not re.fullmatch(r'[a-z][a-z0-9_-]{0,31}', username):
        raise ValueError('Username must be 1-32 lowercase letters, digits, underscores or hyphens, starting with a letter.')
    if username == 'root':
        raise ValueError('The root username is reserved.')
    try:
        account = pwd.getpwnam(username)
    except KeyError:
        account = None
    if account and account.pw_uid < 1000 and username != 'vyos':
        raise ValueError('The requested username is reserved for a system account.')
    if not 12 <= len(password) <= 128 or any(ord(c) < 32 or ord(c) == 127 for c in password):
        raise ValueError('The deployment password must be 12-128 characters without control characters.')
    return username, password


def prepare_config(current, payload, xml):
    credentials = ovf_credentials(xml)
    if not payload.strip() and credentials is None:
        return None
    if payload.strip():
        if len(payload) > 350000:
            raise ValueError('Supplied config.boot exceeds the supported size.')
        try:
            source = base64.b64decode(payload.strip(), validate=True).decode('utf-8-sig')
        except (ValueError, UnicodeError):
            raise ValueError('Invalid base64 config.boot.') from None
    else:
        source = current
    try:
        tree = ConfigTree(source)
    except Exception:
        # Parser exceptions may include input; do not expose configuration secrets.
        raise ValueError('Supplied config.boot could not be parsed.') from None
    if credentials:
        username, password = credentials
        user = ['system', 'login', 'user', username]
        if username != 'vyos' and tree.exists(['system', 'login', 'user', 'vyos']):
            tree.delete(['system', 'login', 'user', 'vyos'])
        plain = user + ['authentication', 'plaintext-password']
        if tree.exists(plain):
            tree.delete(plain)
        password_hash = crypt.crypt(password, crypt.mksalt(crypt.METHOD_SHA512))
        if not password_hash or not password_hash.startswith('$6$'):
            raise ValueError('Could not generate the account password hash.')
        tree.set(user + ['authentication', 'encrypted-password'], value=password_hash)
        tree.set_tag(['system', 'login', 'user'])
    return tree.to_string()


def main():
    if MARKER.exists():
        return
    if subprocess.run(['mountpoint', '-q', '/config'], check=False).returncode:
        raise ValueError('Persistent /config is not mounted; refusing early setup.')
    config = prepare_config(CONFIG.read_text(), guestinfo('guestinfo.vyos.config-b64'),
                            guestinfo('guestinfo.ovfEnv'))
    if config is None:
        MARKER.touch(mode=0o600)
        print('No deployment customization supplied; keeping the installed configuration.')
        return
    # Backup has only the former config; the new plaintext password is never written.
    backup = Path('/config/config.boot.before-injection')
    if not backup.exists():
        with backup.open('x', encoding='utf-8') as f:
            os.chmod(backup, 0o600)
            f.write(CONFIG.read_text())
    import grp
    fd, path = tempfile.mkstemp(prefix='.config.boot.', dir='/config')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            os.fchmod(f.fileno(), 0o660)
            os.fchown(f.fileno(), 0, grp.getgrnam('vyattacfg').gr_gid)
            f.write(config)
            f.flush()
            os.fsync(f.fileno())
        os.replace(path, CONFIG)
    finally:
        if os.path.exists(path):
            os.unlink(path)
    MARKER.touch(mode=0o600)
    os.sync()
    print('Installed deployment configuration and login; rebooting once to activate them.')
    subprocess.run(['systemctl', 'reboot'], check=True)


if __name__ == '__main__':
    try:
        main()
    except ValueError as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
    except Exception:
        print('First-boot setup failed; inspect service status without logging secrets.', file=sys.stderr)
        sys.exit(1)
