<#
.SYNOPSIS
Creates a Windows DPAPI-encrypted vCenter credential file for deploy-vyos-vcenter.ps1.

.DESCRIPTION
The saved credential can be decrypted only by the same Windows user on this
computer. It is never committed to the deployment settings file.
#>
[CmdletBinding()]
param(
    [string]$CredentialFile = (Join-Path $PSScriptRoot 'vcenter-credential.clixml')
)

$credential = Get-Credential -Message 'Credentials for vcenter.example.com'
$credential | Export-Clixml -LiteralPath $CredentialFile
Write-Host "Saved DPAPI-encrypted vCenter credential to $CredentialFile"
